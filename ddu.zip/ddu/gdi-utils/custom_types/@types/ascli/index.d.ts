/**
 * index.ts
 * Created on 2017/Jul/24
 *
 * Author:
 *      "ZongJing Lu <sonic3d@gmail.com>"
 *
 * Copyright (c) 2017 "ZongJing Lu <sonic3d@gmail.com>"
 */

export function ascli(name: string): any;
