
Dream Animator Version 0.50
English Translation by Riley McArdle <rm@softhome.net>


Introduction:

This is an English translation of Dream Animator.  I have been unable to contact the original programmer, F. Sahara, to get his or her permission to make these modifications.  Hopefully it isn't a problem.  If you have any information about the original programmer, please E-Mail me.


Distribution:

I don't know the distribution license that was originally intended.  I am only assuming that the program is freeware.  Please keep this distribution in this original form, with all of the below files:

danime.exe	564,224 bytes		Original Japanese Version of Dream Animator
danim_en.exe	564,224 bytes		English Translation of Dream Animator
readme.txt	1,418 bytes		This file


Notes:

- I couldn't figure out what one word ment in the bottom item of the Animation menu, but that function isn't implemented yet, so it isn't a big deal.
- The original program I got didn't have an about box, even though the menu is there.
- In the Export dialog, there are two types of bitmap listed, from what I can tell, there is no difference between the two.
- Yeah, I know there's a lot of problems with the spacing.  I couldn't fix it though.


Contact:

If you have any questions or comments, please E-Mail me at rm@softhome.net, especially if you have any information about the original programmer.
